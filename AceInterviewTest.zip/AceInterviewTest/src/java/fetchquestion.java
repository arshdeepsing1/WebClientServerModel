import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import vmm.DBLoader;
import vmm.RDBMS_TO_JSON;
public class fetchquestion extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException 
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String Sectionid= request.getParameter("Sectionid");
        
        String mainjson1 = new RDBMS_TO_JSON().generateJSON("select * from questions where Sectionid="+ Sectionid);
      
      
        
            out.println(mainjson1);
          
          }
    
    



    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}


